import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../models/menu_item.dart';
import '../../models/order.dart';
import '../../models/order_item.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('vendor_pos.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const textType = 'TEXT NOT NULL';
    const realType = 'REAL NOT NULL';
    const intType = 'INTEGER NOT NULL';

    // Menu Items Table
    await db.execute('''
    CREATE TABLE menu_items (
      id $idType,
      name $textType,
      basePrice $realType,
      category $textType,
      isAvailable INTEGER DEFAULT 1,
      createdAt $textType
    )
    ''');

    // Orders Table
    await db.execute('''
    CREATE TABLE orders (
      id $idType,
      orderNumber $textType,
      totalAmount $realType,
      paymentMethod $textType,
      status $textType,
      createdAt $textType
    )
    ''');

    // Order Items Table
    await db.execute('''
    CREATE TABLE order_items (
      id $idType,
      orderId $intType,
      menuItemId $intType,
      menuItemName $textType,
      quantity $intType,
      price $realType,
      subtotal $realType,
      FOREIGN KEY (orderId) REFERENCES orders (id) ON DELETE CASCADE
    )
    ''');
  }

  // Menu Items CRUD
  Future<int> createMenuItem(MenuItem item) async {
    final db = await database;
    return await db.insert('menu_items', item.toJson());
  }

  Future<List<MenuItem>> getAllMenuItems() async {
    final db = await database;
    final result = await db.query('menu_items', orderBy: 'category, name');
    return result.map((json) => MenuItem.fromJson(json)).toList();
  }

  Future<int> updateMenuItem(MenuItem item) async {
    final db = await database;
    return await db.update(
      'menu_items',
      item.toJson(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<int> deleteMenuItem(int id) async {
    final db = await database;
    return await db.delete(
      'menu_items',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Orders CRUD
  Future<int> createOrder(Order order) async {
    final db = await database;
    final orderId = await db.insert('orders', order.toJson());
    
    // Insert order items
    for (var item in order.items) {
      await db.insert('order_items', {
        'orderId': orderId,
        'menuItemId': item.menuItemId,
        'menuItemName': item.menuItemName,
        'quantity': item.quantity,
        'price': item.price,
        'subtotal': item.subtotal,
      });
    }
    
    return orderId;
  }

  Future<List<Order>> getAllOrders() async {
    final db = await database;
    final result = await db.query('orders', orderBy: 'createdAt DESC');
    
    List<Order> orders = [];
    for (var orderMap in result) {
      final items = await db.query(
        'order_items',
        where: 'orderId = ?',
        whereArgs: [orderMap['id']],
      );
      
      final orderItems = items.map((item) => OrderItem.fromJson(item)).toList();
      orders.add(Order.fromJson(orderMap, orderItems));
    }
    
    return orders;
  }

  Future<List<Order>> getOrdersByDate(DateTime date) async {
    final db = await database;
    final startOfDay = DateTime(date.year, date.month, date.day);
    final endOfDay = DateTime(date.year, date.month, date.day, 23, 59, 59);
    
    final result = await db.query(
      'orders',
      where: 'createdAt >= ? AND createdAt <= ?',
      whereArgs: [startOfDay.toIso8601String(), endOfDay.toIso8601String()],
      orderBy: 'createdAt DESC',
    );
    
    List<Order> orders = [];
    for (var orderMap in result) {
      final items = await db.query(
        'order_items',
        where: 'orderId = ?',
        whereArgs: [orderMap['id']],
      );
      
      final orderItems = items.map((item) => OrderItem.fromJson(item)).toList();
      orders.add(Order.fromJson(orderMap, orderItems));
    }
    
    return orders;
  }

  Future<Map<String, dynamic>> getTodayStats() async {
    final today = DateTime.now();
    final orders = await getOrdersByDate(today);
    
    double totalRevenue = 0;
    int totalOrders = orders.length;
    int cashPayments = 0;
    int upiPayments = 0;
    
    for (var order in orders) {
      totalRevenue += order.totalAmount;
      if (order.paymentMethod == 'Cash') {
        cashPayments++;
      } else {
        upiPayments++;
      }
    }
    
    return {
      'totalRevenue': totalRevenue,
      'totalOrders': totalOrders,
      'cashPayments': cashPayments,
      'upiPayments': upiPayments,
    };
  }

  Future<void> close() async {
    final db = await database;
    db.close();
  }
}
