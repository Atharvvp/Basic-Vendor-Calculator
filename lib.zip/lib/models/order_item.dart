class OrderItem {
  final int? id;
  final int menuItemId;
  final String menuItemName;
  final int quantity;
  final double price;
  final double subtotal;

  OrderItem({
    this.id,
    required this.menuItemId,
    required this.menuItemName,
    required this.quantity,
    required this.price,
    required this.subtotal,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'menuItemId': menuItemId,
      'menuItemName': menuItemName,
      'quantity': quantity,
      'price': price,
      'subtotal': subtotal,
    };
  }

  factory OrderItem.fromJson(Map<String, dynamic> json) {
    return OrderItem(
      id: json['id'] as int?,
      menuItemId: json['menuItemId'] as int,
      menuItemName: json['menuItemName'] as String,
      quantity: json['quantity'] as int,
      price: json['price'] as double,
      subtotal: json['subtotal'] as double,
    );
  }
}
