import 'order_item.dart';

class Order {
  final int? id;
  final String orderNumber;
  final double totalAmount;
  final String paymentMethod; // 'Cash' or 'UPI'
  final String status; // 'Completed', 'Cancelled'
  final DateTime createdAt;
  final List<OrderItem> items;

  Order({
    this.id,
    required this.orderNumber,
    required this.totalAmount,
    required this.paymentMethod,
    this.status = 'Completed',
    DateTime? createdAt,
    required this.items,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'orderNumber': orderNumber,
      'totalAmount': totalAmount,
      'paymentMethod': paymentMethod,
      'status': status,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory Order.fromJson(Map<String, dynamic> json, List<OrderItem> items) {
    return Order(
      id: json['id'] as int?,
      orderNumber: json['orderNumber'] as String,
      totalAmount: json['totalAmount'] as double,
      paymentMethod: json['paymentMethod'] as String,
      status: json['status'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      items: items,
    );
  }

  static String generateOrderNumber() {
    final now = DateTime.now();
    return 'ORD${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}${now.second.toString().padLeft(2, '0')}';
  }
}
