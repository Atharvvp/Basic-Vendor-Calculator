class MenuItem {
  final int? id;
  final String name;
  final double basePrice;
  final String category;
  final bool isAvailable;
  final DateTime createdAt;

  MenuItem({
    this.id,
    required this.name,
    required this.basePrice,
    required this.category,
    this.isAvailable = true,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'basePrice': basePrice,
      'category': category,
      'isAvailable': isAvailable ? 1 : 0,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id'] as int?,
      name: json['name'] as String,
      basePrice: json['basePrice'] as double,
      category: json['category'] as String,
      isAvailable: json['isAvailable'] == 1,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  MenuItem copyWith({
    int? id,
    String? name,
    double? basePrice,
    String? category,
    bool? isAvailable,
    DateTime? createdAt,
  }) {
    return MenuItem(
      id: id ?? this.id,
      name: name ?? this.name,
      basePrice: basePrice ?? this.basePrice,
      category: category ?? this.category,
      isAvailable: isAvailable ?? this.isAvailable,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
